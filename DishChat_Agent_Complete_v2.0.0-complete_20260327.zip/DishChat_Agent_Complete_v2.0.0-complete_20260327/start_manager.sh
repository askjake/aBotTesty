#!/bin/bash
# Dish-Chat Agent Complete Bundle - Master Launcher
# Version: v2.0.0-complete
# This launches the GUI manager which controls all services

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# ASCII Art Banner
echo -e "${CYAN}"
cat << "EOF"
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║     ██████╗ ██╗███████╗██╗  ██╗     ██████╗██╗  ██╗     ║
║     ██╔══██╗██║██╔════╝██║  ██║    ██╔════╝██║  ██║     ║
║     ██║  ██║██║███████╗███████║    ██║     ███████║     ║
║     ██║  ██║██║╚════██║██╔══██║    ██║     ██╔══██║     ║
║     ██████╔╝██║███████║██║  ██║    ╚██████╗██║  ██║     ║
║     ╚═════╝ ╚═╝╚══════╝╚═╝  ╚═╝     ╚═════╝╚═╝  ╚═╝     ║
║                                                           ║
║              A G E N T   M A N A G E R                    ║
║                  v2.0.0-complete                          ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

echo ""
echo -e "${BLUE}┌─────────────────────────────────────────────────────────┐${NC}"
echo -e "${BLUE}│${NC}  Welcome to Dish-Chat Agent Complete Bundle          ${BLUE}│${NC}"
echo -e "${BLUE}└─────────────────────────────────────────────────────────┘${NC}"
echo ""

# Check Python
echo -e "${YELLOW}[1/4]${NC} Checking Python..."
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}✗ Python 3 not found!${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Python 3 available${NC}"
echo ""

# Check/Install Streamlit
echo -e "${YELLOW}[2/4]${NC} Checking Streamlit..."
if ! python3 -c "import streamlit" &> /dev/null; then
    echo -e "${YELLOW}⚠ Streamlit not found. Installing...${NC}"
    pip install streamlit requests &> /tmp/streamlit_install.log
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Streamlit installed${NC}"
    else
        echo -e "${RED}✗ Streamlit installation failed. Check /tmp/streamlit_install.log${NC}"
        exit 1
    fi
else
    echo -e "${GREEN}✓ Streamlit available${NC}"
fi
echo ""

# Verify bundle structure
echo -e "${YELLOW}[3/4]${NC} Verifying bundle structure..."
required_dirs=("backend" "frontend" "gui" "docs" "scripts" "logs" "run")
all_good=true
for dir in "${required_dirs[@]}"; do
    if [ -d "$dir" ]; then
        echo -e "  ${GREEN}✓${NC} $dir/"
    else
        echo -e "  ${RED}✗${NC} $dir/ (missing)"
        all_good=false
    fi
done

if [ "$all_good" = false ]; then
    echo -e "${RED}✗ Bundle structure incomplete!${NC}"
    exit 1
fi
echo ""

# Launch GUI Manager
echo -e "${YELLOW}[4/4]${NC} Launching GUI Manager..."
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  🚀 Starting Dish-Chat Agent Manager${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  ${YELLOW}→${NC} Manager UI:  ${CYAN}http://localhost:8501${NC}"
echo ""
echo -e "  Use the GUI to:"
echo -e "    • Start/stop all services"
echo -e "    • Configure agent settings"
echo -e "    • View logs and status"
echo -e "    • Monitor performance"
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Press Ctrl+C to stop the manager${NC}"
echo ""

cd gui
python3 -m streamlit run agent_manager.py \
    --server.port 8501 \
    --server.address localhost \
    --server.headless true \
    --browser.gatherUsageStats false \
    --theme.base light
