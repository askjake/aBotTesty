# Streamlit + oauth2-proxy + Nginx local SSO bundle

This bundle gives you:

- a `Dockerfile` for the Streamlit frontend
- `docker-compose.yml` to run Streamlit, oauth2-proxy, and Nginx
- `oauth2-proxy.cfg.template` for generic OIDC / Okta-style login
- `nginx.conf` that injects `X-Auth-Request-Email` into the app

## Files
- `Dockerfile`
- `docker-compose.yml`
- `oauth2-proxy.cfg.template`
- `nginx.conf`
- `streamlit_dishchat.py`
- `requirements.txt`

## Quick start

1. Copy the template:

   ```bash
   cp oauth2-proxy.cfg.template oauth2-proxy.cfg
   ```

2. Generate a cookie secret:

   ```bash
   ./gen_cookie_secret.sh
   ```

3. Edit `oauth2-proxy.cfg` and fill in:
   - `oidc_issuer_url`
   - `client_id`
   - `client_secret`
   - `cookie_secret`

4. Make sure your backend is running on the host machine:

   ```bash
   curl http://127.0.0.1:8000/rest/api/v1/health
   ```

5. Start the local SSO frontend stack:

   ```bash
   docker compose up --build
   ```

6. Open:

   ```text
   http://localhost:8088
   ```

## Notes
- Streamlit talks to the backend at `http://host.docker.internal:8000`
- Nginx protects the app with oauth2-proxy
- oauth2-proxy injects `X-Auth-Request-Email`
- `cookie_secure = false` is only for local HTTP testing
