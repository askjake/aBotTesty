import json
import os
from typing import Any

import requests
import streamlit as st

BACKEND_URL = os.getenv("STREAMLIT_BACKEND_URL", os.getenv("BACKEND_URL", "http://127.0.0.1:8000")).rstrip("/")
API_PREFIX = os.getenv("API_PREFIX", "/rest/api/v1")
DEFAULT_NAMESPACE = os.getenv("NAMESPACE", "generic")
FALLBACK_USER_EMAIL = os.getenv("USER_EMAIL", "test.test@dish.com")

st.set_page_config(page_title="Dish Chat Local", layout="wide")


def backend(path: str) -> str:
    return f"{BACKEND_URL}{API_PREFIX}{path}"


def safe_rerun() -> None:
    if hasattr(st, "rerun"):
        st.rerun()
        return
    if hasattr(st, "experimental_rerun"):
        st.experimental_rerun()


def auth_email() -> str:
    headers = getattr(st.context, "headers", {}) or {}
    return (
        headers.get("x-auth-request-email")
        or headers.get("X-Auth-Request-Email")
        or FALLBACK_USER_EMAIL
    )


def auth_headers() -> dict[str, str]:
    email = auth_email()
    return {
        "X-Auth-Request-Email": email,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def health():
    try:
        r = requests.get(backend("/health"), timeout=10)
        return r.status_code, r.text
    except Exception as e:
        return None, str(e)


def _coerce_list_payload(data: Any) -> list[dict]:
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("docs", "items", "results", "data", "messages", "chats"):
            value = data.get(key)
            if isinstance(value, list):
                return value
        return [data]
    return []


def list_chats() -> list[dict]:
    try:
        r = requests.get(
            backend(f"/chats?namespace={DEFAULT_NAMESPACE}&page=1&limit=100"),
            headers=auth_headers(),
            timeout=20,
        )
        if r.ok:
            return _coerce_list_payload(r.json())
    except Exception:
        pass
    return []


def create_chat():
    try:
        r = requests.post(
            backend(f"/chats?namespace={DEFAULT_NAMESPACE}"),
            headers=auth_headers(),
            timeout=20,
        )
        if r.ok:
            data = r.json()
            return data.get("chat_id") or data.get("id") or data.get("uuid"), data
        return None, r.text
    except Exception as e:
        return None, str(e)


def fetch_messages(chat_id: str) -> list[dict]:
    try:
        r = requests.get(backend(f"/chats/{chat_id}/messages"), headers=auth_headers(), timeout=20)
        if r.ok:
            data = r.json()
            msgs = _coerce_list_payload(data)
            # Backend paginated endpoint returns newest-first docs.
            msgs.reverse()
            return msgs
    except Exception:
        pass
    return []


def _extract_text_from_content(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = [_extract_text_from_content(item) for item in content]
        return "\n\n".join(part for part in parts if part)
    if isinstance(content, dict):
        if "type" in content and content.get("type") == "text":
            return str(content.get("text", ""))
        # Message content shape: {"0": {"type":"text","text":"..."}}
        parts: list[str] = []
        for key in sorted(content.keys(), key=lambda x: int(x) if str(x).isdigit() else str(x)):
            value = content[key]
            text = _extract_text_from_content(value)
            if text:
                parts.append(text)
        if parts:
            return "\n\n".join(parts)
        return json.dumps(content, ensure_ascii=False)
    return str(content)


def render_message_text(message: dict) -> str:
    for key in ("content", "text", "message", "answer"):
        if key in message:
            text = _extract_text_from_content(message.get(key))
            if text:
                return text
    return json.dumps(message, ensure_ascii=False, indent=2)


def stream_message(chat_id: str, message: str) -> str:
    url = backend(f"/chats/{chat_id}/messages")
    payloads = [
        {
            "content": message,
            "message_config": {"temperature": None, "reasoning": None},
            "attachments": [],
        },
        {"content": message},
    ]
    last_error = ""
    for payload in payloads:
        try:
            with requests.post(url, headers=auth_headers(), json=payload, stream=True, timeout=300) as r:
                if not r.ok:
                    last_error = f"[{r.status_code}] {r.text}"
                    continue

                text = ""
                holder = st.empty()

                for raw in r.iter_lines(decode_unicode=True):
                    if not raw:
                        continue
                    line = raw.strip()
                    if line.startswith("data:"):
                        data_str = line[5:].strip()
                        if data_str == "[DONE]":
                            break
                        try:
                            data = json.loads(data_str)
                        except Exception:
                            if data_str:
                                text += data_str
                                holder.markdown(text)
                            continue

                        delta = data.get("delta") or {}
                        chunk = (
                            (delta.get("text") if isinstance(delta, dict) else None)
                            or data.get("content")
                            or data.get("text")
                            or data.get("message")
                            or data.get("answer")
                            or ""
                        )
                        if isinstance(chunk, list):
                            chunk = "".join(_extract_text_from_content(x) for x in chunk)
                        elif isinstance(chunk, dict):
                            chunk = _extract_text_from_content(chunk)
                        if chunk:
                            text += str(chunk)
                            holder.markdown(text)

                if text:
                    return text
                return ""
        except Exception as e:
            last_error = str(e)
    return last_error or "No response"


def fetch_llm_settings():
    try:
        r = requests.get(backend("/settings/llm"), headers=auth_headers(), timeout=15)
        if r.ok:
            return r.json(), None
        return None, f"[{r.status_code}] {r.text}"
    except Exception as e:
        return None, str(e)


def update_llm_settings_ui(provider: str, model_name: str):
    llm_data, _ = fetch_llm_settings()
    efficient_cfg = (llm_data or {}).get("efficient_llm") or {}
    payload = {
        "power_llm": {
            "provider": provider,
            "model_name": model_name,
            "temperature": 0.6,
            "api_base": None,
            "api_key": None,
        },
        "efficient_llm": {
            "provider": efficient_cfg.get("provider") or provider,
            "model_name": efficient_cfg.get("model_name") or model_name,
            "temperature": 0.6,
            "api_base": efficient_cfg.get("api_base"),
            "api_key": None,
        },
    }
    try:
        r = requests.post(backend("/settings/llm/update"), headers=auth_headers(), json=payload, timeout=20)
        if r.ok:
            return True, r.json()
        return False, f"[{r.status_code}] {r.text}"
    except Exception as e:
        return False, str(e)


if "chat_id" not in st.session_state:
    st.session_state.chat_id = None

st.title("Dish Chat Local")
st.caption("Local Streamlit frontend for the Dish-Chat backend.")

with st.sidebar:
    st.subheader("Connection")
    st.write(f"**Backend:** `{BACKEND_URL}{API_PREFIX}`")
    st.write(f"**User:** `{auth_email()}`")
    code, body = health()
    if code == 200:
        st.success("Backend healthy")
    else:
        st.warning(f"Health: {code} {body}")

    llm_data, llm_error = fetch_llm_settings()
    with st.expander("LLM settings", expanded=False):
        if llm_error:
            st.warning(f"Could not load LLM settings: {llm_error}")
        elif llm_data:
            providers = llm_data.get("available_providers", []) or []
            power_cfg = llm_data.get("power_llm", {}) or {}
            current_provider = power_cfg.get("provider") or "coverity-assist"
            current_model = power_cfg.get("model_name") or "coverity-assist"

            provider_ids = [p.get("id") for p in providers]
            provider_labels = {p.get("id"): p.get("name") or p.get("id") for p in providers}

            if provider_ids:
                default_index = provider_ids.index(current_provider) if current_provider in provider_ids else 0
                selected_provider = st.selectbox(
                    "Provider",
                    provider_ids,
                    index=default_index,
                    format_func=lambda pid: provider_labels.get(pid, pid),
                )

                models_for_provider = []
                for p in providers:
                    if p.get("id") == selected_provider:
                        models_for_provider = p.get("models") or []
                        break

                if models_for_provider:
                    model_index = models_for_provider.index(current_model) if current_model in models_for_provider else 0
                    selected_model = st.selectbox("Model", models_for_provider, index=model_index)
                    if st.button("Apply LLM configuration"):
                        ok, resp = update_llm_settings_ui(selected_provider, selected_model)
                        if ok:
                            st.success("Saved. Restart backend to apply.")
                            safe_rerun()
                        else:
                            st.error(f"Failed to update LLM settings: {resp}")

    if st.button("Create new chat"):
        chat_id, data = create_chat()
        if chat_id:
            st.session_state.chat_id = chat_id
            st.success(f"Created chat: {chat_id}")
            safe_rerun()
        else:
            st.error(f"Could not create chat. Response: {data}")

    chats = list_chats()
    options = {}
    for c in chats:
        cid = c.get("chat_id") or c.get("id") or c.get("uuid")
        label = c.get("title") or c.get("name") or cid or "unknown"
        if cid:
            options[f"{label} :: {cid}"] = cid

    if options:
        selected = st.selectbox("Existing chats", [""] + list(options.keys()))
        if selected:
            st.session_state.chat_id = options[selected]

    st.text_input("Active chat", key="chat_id")

if st.session_state.chat_id:
    st.subheader(f"Chat {st.session_state.chat_id}")
    msgs = fetch_messages(st.session_state.chat_id)
    for m in msgs:
        role = m.get("role") or m.get("sender") or "message"
        with st.chat_message("assistant" if role == "assistant" else "user"):
            st.markdown(render_message_text(m))

    prompt = st.chat_input("Send a message")
    if prompt:
        with st.chat_message("user"):
            st.markdown(prompt)
        with st.chat_message("assistant"):
            _ = stream_message(st.session_state.chat_id, prompt)
        safe_rerun()
else:
    st.info("Create or select a chat in the sidebar.")
