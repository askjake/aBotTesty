# Dish-Chat Agent Complete Bundle

**Version:** v2.0.0-complete  
**Release Date:** 2026-03-27  
**Bundle:** Complete package with GUI manager

---

## 🎯 Quick Start (3 Steps)

### 1. Extract the bundle:
```bash
tar -xzf DishChat_Agent_Complete_v2.0.0-complete_20260327.tar.gz
cd DishChat_Agent_Complete_v2.0.0-complete_20260327
```

### 2. Launch the GUI Manager:
```bash
bash start_manager.sh
```

### 3. Open your browser:
```
http://localhost:8501
```

**That's it!** Use the GUI to manage everything.

---

## 📦 What's Included

### Complete Package:
```
DishChat_Agent_Complete_v2.0.0-complete_20260327/
├── start_manager.sh              # 🚀 MASTER LAUNCHER (START HERE)
├── VERSION                        # Version information
├── README.md                      # This file
├── RELEASE_NOTES.md               # Detailed changelog
│
├── backend/                       # Enhanced Backend API
│   ├── coverity_assist_gateway_chat_proxy.py  # Enhanced proxy (8192/16384 tokens)
│   ├── .env                                    # Configuration
│   └── app/                                    # FastAPI application
│
├── frontend/                      # Web Frontend (optional)
│   └── [frontend files]
│
├── gui/                           # 🎛️ GUI MANAGER
│   ├── agent_manager.py                        # Streamlit management interface
│   └── launch_manager.sh                       # GUI launcher
│
├── docs/                          # Documentation
│   ├── START_HERE.md                           # Quick start guide
│   ├── ENHANCEMENT_SUMMARY.md                  # Technical details
│   ├── README.md                               # Full documentation
│   └── QUICKREF.txt                            # Command reference
│
├── scripts/                       # Utility Scripts
│   ├── start-enhanced-agent.sh                 # CLI service starter
│   └── test-agent.sh                           # Test suite
│
├── logs/                          # Log Directory
│   └── [service logs appear here]
│
└── run/                           # PID Files
    └── [process IDs stored here]
```

---

## 🎛️ GUI Manager Features

The GUI Manager provides a complete interface for managing your agent:

### 📊 Dashboard Tab
- Real-time service status (Proxy, Backend, Frontend)
- Health checks and URLs
- System metrics (max tokens, agent mode, etc.)
- Quick log viewing

### ⚙️ Configuration Tab
- Adjust max tokens (1024-32768)
- Enable/disable agent mode
- Set tool execution steps
- Configure debug mode
- Edit all settings with live validation

### 📋 Logs Tab
- View all service logs in real-time
- Filter by service (proxy, backend, frontend)
- Auto-refresh option
- Tail N lines display
- Clear logs function

### ℹ️ About Tab
- Version information
- Feature list
- Documentation links
- Quick actions (run tests, check version)

### 🎛️ Sidebar Controls
- **Start All Services** - One-click startup with auto port detection
- **Stop All Services** - Graceful shutdown of all components
- **Restart All** - Quick restart for applying changes
- Live status indicators (🟢/🔴)

---

## ⚙️ Configuration

The GUI Manager allows you to configure all settings visually, or you can edit `.env` manually:

### Key Settings:

| Setting | Default | Description |
|---------|---------|-------------|
| `COVERITY_ASSIST_MAX_TOKENS` | 8192 | Default max tokens (was 1024) |
| `COVERITY_ASSIST_PROXY_MAX_TOKENS` | 16384 | Proxy cap (was 2048) |
| `COVERITY_ASSIST_AGENT_TOOL_MODE` | 1 | Enable agent mode |
| `COVERITY_ASSIST_TOOL_MAX_STEPS` | 100 | Max tool execution steps |
| `DEBUG` | 1 | Enable debug logging |

All settings can be changed via the GUI Configuration tab.

---

## 🚀 Starting Services

### Option 1: GUI Manager (Recommended)
```bash
bash start_manager.sh
# Then use the web interface at http://localhost:8501
```

### Option 2: Command Line
```bash
bash scripts/start-enhanced-agent.sh
```

### Option 3: Manual
```bash
# Start proxy
cd backend
/home/montjac/JAMboree/JAMboree/vJAM/bin/python coverity_assist_gateway_chat_proxy.py --port 5001 &

# Start backend
/home/montjac/dish-chat/.venv/bin/python -m uvicorn app.main:app --port 8001 &
```

---

## 🧪 Testing

### Via GUI:
- Go to "About" tab → Click "Run Tests"

### Via Command Line:
```bash
bash scripts/test-agent.sh
```

---

## 📊 Service URLs

Default ports (auto-adjusted if in use):

- **GUI Manager:** http://localhost:8501
- **Proxy Gateway:** http://localhost:5001
- **Backend API:** http://localhost:8001
- **Frontend UI:** http://localhost:3000 (if enabled)

---

## 🛑 Stopping Services

### Via GUI:
- Click "Stop All Services" in the sidebar

### Via Command Line:
```bash
# If you have PIDs saved
kill $(cat run/proxy.pid run/backend.pid)

# Or by process name
pkill -f "coverity_assist_gateway_chat_proxy"
pkill -f "uvicorn app.main:app"
```

---

## 📈 What's Enhanced

Compared to the original AgentJake:

| Feature | Original | Enhanced | Improvement |
|---------|----------|----------|-------------|
| Default max_tokens | 1024 | **8192** | **8x** |
| Proxy cap | 2048 | **16384** | **8x** |
| Retry cap | 1024 | **16384** | **16x** |
| Agent mode | Implicit | **Explicit** | Configured |
| Port detection | Manual | **Automatic** | Dynamic |
| **Management** | **CLI only** | **GUI + CLI** | **Added** |
| **Documentation** | **Minimal** | **Complete** | **4 docs** |

---

## 🔧 Troubleshooting

### GUI Manager won't start:
```bash
# Install/update Streamlit
pip install --upgrade streamlit requests

# Try launching directly
cd gui
python3 -m streamlit run agent_manager.py
```

### Services won't start:
1. Check logs in `logs/` directory
2. Verify ports are free: `lsof -i :5001 -i :8001`
3. Check configuration in `backend/.env`

### Configuration not applying:
1. Save configuration in GUI
2. Click "Restart All Services" in sidebar
3. Verify changes in `backend/.env`

---

## 📚 Documentation

Inside the `docs/` directory:

1. **START_HERE.md** - Quick start guide for command-line usage
2. **ENHANCEMENT_SUMMARY.md** - Technical details of enhancements
3. **README.md** - Full documentation
4. **QUICKREF.txt** - Quick reference commands

---

## 🎓 Requirements

### Minimum:
- Python 3.8+
- 2GB RAM
- 1GB disk space

### Python Packages:
- streamlit (for GUI)
- requests (for health checks)
- All backend requirements (auto-installed from requirements.txt)

---

## 🔄 Updating Configuration

### Via GUI (Easiest):
1. Open http://localhost:8501
2. Go to "Configuration" tab
3. Adjust settings
4. Click "Save Configuration"
5. Restart services from sidebar

### Via File:
1. Edit `backend/.env`
2. Restart services

---

## 💡 Tips

1. **Always use the GUI Manager** - It handles everything automatically
2. **Check logs** - Use the Logs tab to troubleshoot
3. **Auto port detection** - Services will find free ports automatically
4. **Save configs before restarting** - Changes only apply after restart
5. **Use Dashboard metrics** - Monitor max tokens and agent mode status

---

## 🎉 Success Checklist

After starting:
- [ ] GUI Manager opens at http://localhost:8501
- [ ] Dashboard shows all services green (🟢)
- [ ] Proxy health check passes
- [ ] Backend health check passes
- [ ] Configuration shows correct max_tokens (8192)
- [ ] Agent mode is enabled
- [ ] Logs show no errors

---

## 📞 Support

- **Logs:** Check `logs/` directory or use GUI Logs tab
- **Status:** Use GUI Dashboard tab
- **Config:** Use GUI Configuration tab
- **Docs:** See `docs/` directory
- **Tests:** Run `bash scripts/test-agent.sh`

---

## 🎯 Quick Actions

```bash
# Start everything
bash start_manager.sh

# Run tests
bash scripts/test-agent.sh

# View logs
tail -f logs/proxy.log
tail -f logs/backend.log

# Check status
lsof -i :5001 -i :8001 -i :8501

# Stop everything
pkill -f streamlit
pkill -f coverity_assist_gateway_chat_proxy
pkill -f "uvicorn app.main:app"
```

---

**Ready to go! Just run:** `bash start_manager.sh`

**Version:** v2.0.0-complete  
**Build:** 20260327-102338  
**Status:** Production Ready ✅
