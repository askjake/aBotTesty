#!/bin/bash
# Dish-Chat Agent Manager Launcher
# Version: v2.0.0-enhanced

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Check if streamlit is available
if ! command -v streamlit &> /dev/null; then
    echo "❌ Streamlit not found. Installing..."
    pip install streamlit requests
fi

# Launch the GUI
echo "🚀 Starting Dish-Chat Agent Manager..."
echo "   Opening browser at http://localhost:8501"
echo ""
streamlit run agent_manager.py --server.port 8501 --server.address localhost
