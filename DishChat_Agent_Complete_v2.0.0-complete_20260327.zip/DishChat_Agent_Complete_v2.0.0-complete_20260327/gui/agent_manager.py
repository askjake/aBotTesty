#!/usr/bin/env python3
"""
Dish-Chat Agent Manager
A GUI application for managing the Dish-Chat agent

Version: v2.0.0-enhanced
"""
import streamlit as st
import subprocess
import os
import signal
import json
from pathlib import Path
import time
import requests

# Page config
st.set_page_config(
    page_title="Dish-Chat Agent Manager",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Paths
BASE_DIR = Path(__file__).parent.parent
BACKEND_DIR = BASE_DIR / "backend"
FRONTEND_DIR = BASE_DIR / "frontend"
LOGS_DIR = BASE_DIR / "logs"
ENV_FILE = BACKEND_DIR / ".env"
PID_DIR = BASE_DIR / "run"

# Create necessary directories
LOGS_DIR.mkdir(exist_ok=True)
PID_DIR.mkdir(exist_ok=True)

# Helper functions
def read_pid_file(name):
    """Read PID from file"""
    pid_file = PID_DIR / f"{name}.pid"
    if pid_file.exists():
        try:
            return int(pid_file.read_text().strip())
        except:
            return None
    return None

def write_pid_file(name, pid):
    """Write PID to file"""
    pid_file = PID_DIR / f"{name}.pid"
    pid_file.write_text(str(pid))

def is_process_running(pid):
    """Check if process is running"""
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False

def find_free_port(start, end):
    """Find a free port in range"""
    import socket
    for port in range(start, end):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(('', port))
                return port
            except OSError:
                continue
    return None

def check_service_health(url):
    """Check if service is healthy"""
    try:
        response = requests.get(url, timeout=2)
        return response.ok
    except:
        return False

def load_env_file():
    """Load .env file as dict"""
    env = {}
    if ENV_FILE.exists():
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    env[key] = value
    return env

def save_env_file(env):
    """Save dict to .env file"""
    with open(ENV_FILE, 'w') as f:
        f.write("# Dish-Chat Agent Configuration\n")
        f.write(f"# Updated: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        for key, value in sorted(env.items()):
            f.write(f"{key}={value}\n")

# Title
st.title("🤖 Dish-Chat Agent Manager")
st.markdown("**Version:** v2.0.0-enhanced")

# Sidebar - Service Control
st.sidebar.header("🎛️ Service Control")

# Check service status
proxy_pid = read_pid_file("proxy")
backend_pid = read_pid_file("backend")
frontend_pid = read_pid_file("frontend")

proxy_running = is_process_running(proxy_pid)
backend_running = is_process_running(backend_pid)
frontend_running = is_process_running(frontend_pid)

# Service status
st.sidebar.subheader("Service Status")
col1, col2 = st.sidebar.columns([3, 1])
with col1:
    st.write("Proxy Gateway:")
with col2:
    st.write("🟢" if proxy_running else "🔴")

col1, col2 = st.sidebar.columns([3, 1])
with col1:
    st.write("Backend API:")
with col2:
    st.write("🟢" if backend_running else "🔴")

col1, col2 = st.sidebar.columns([3, 1])
with col1:
    st.write("Frontend UI:")
with col2:
    st.write("🟢" if frontend_running else "🔴")

st.sidebar.markdown("---")

# Start/Stop controls
if st.sidebar.button("🚀 Start All Services", use_container_width=True):
    with st.spinner("Starting services..."):
        # Find free ports
        proxy_port = find_free_port(5000, 5100)
        backend_port = find_free_port(8000, 8100)
        frontend_port = find_free_port(3000, 3100)
        
        success = True
        messages = []
        
        # Start proxy
        if not proxy_running:
            try:
                proc = subprocess.Popen(
                    ["/home/montjac/JAMboree/JAMboree/vJAM/bin/python", 
                     "coverity_assist_gateway_chat_proxy.py", "--port", str(proxy_port)],
                    cwd=str(BACKEND_DIR),
                    stdout=open(LOGS_DIR / "proxy.log", "w"),
                    stderr=subprocess.STDOUT
                )
                write_pid_file("proxy", proc.pid)
                messages.append(f"✅ Proxy started on port {proxy_port}")
            except Exception as e:
                messages.append(f"❌ Proxy failed: {e}")
                success = False
        
        # Start backend
        if not backend_running:
            try:
                proc = subprocess.Popen(
                    ["/home/montjac/dish-chat/.venv/bin/python", "-m", "uvicorn",
                     "app.main:app", "--host", "0.0.0.0", "--port", str(backend_port)],
                    cwd=str(BACKEND_DIR),
                    stdout=open(LOGS_DIR / "backend.log", "w"),
                    stderr=subprocess.STDOUT
                )
                write_pid_file("backend", proc.pid)
                messages.append(f"✅ Backend started on port {backend_port}")
            except Exception as e:
                messages.append(f"❌ Backend failed: {e}")
                success = False
        
        # Show results
        for msg in messages:
            st.sidebar.success(msg) if "✅" in msg else st.sidebar.error(msg)
        
        time.sleep(2)
        st.rerun()

if st.sidebar.button("🛑 Stop All Services", use_container_width=True):
    with st.spinner("Stopping services..."):
        stopped = []
        
        # Stop each service
        for name, pid in [("proxy", proxy_pid), ("backend", backend_pid), ("frontend", frontend_pid)]:
            if pid and is_process_running(pid):
                try:
                    os.kill(pid, signal.SIGTERM)
                    stopped.append(f"✅ Stopped {name}")
                except Exception as e:
                    stopped.append(f"❌ Failed to stop {name}: {e}")
        
        for msg in stopped:
            st.sidebar.success(msg) if "✅" in msg else st.sidebar.error(msg)
        
        time.sleep(1)
        st.rerun()

st.sidebar.markdown("---")

if st.sidebar.button("🔄 Restart All", use_container_width=True):
    st.sidebar.info("Stopping services...")
    # Stop all
    for name, pid in [("proxy", proxy_pid), ("backend", backend_pid), ("frontend", frontend_pid)]:
        if pid and is_process_running(pid):
            try:
                os.kill(pid, signal.SIGTERM)
            except:
                pass
    time.sleep(2)
    st.rerun()

# Main content - Tabs
tab1, tab2, tab3, tab4 = st.tabs(["📊 Dashboard", "⚙️ Configuration", "📋 Logs", "ℹ️ About"])

with tab1:
    st.header("Service Dashboard")
    
    # Service details
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.subheader("🌐 Proxy Gateway")
        if proxy_running:
            st.success(f"**Status:** Running (PID: {proxy_pid})")
            # Try to get health
            env = load_env_file()
            proxy_url = env.get("COVERITY_ASSIST_URL", "http://127.0.0.1:5001")
            health_url = proxy_url.replace("/chat", "/health")
            if check_service_health(health_url):
                st.info(f"**Health:** ✅ Healthy")
                st.code(health_url, language="text")
            else:
                st.warning("**Health:** ⚠️ Not responding")
        else:
            st.error("**Status:** Stopped")
        
        if st.button("View Proxy Logs", key="view_proxy"):
            log_file = LOGS_DIR / "proxy.log"
            if log_file.exists():
                st.code(log_file.read_text()[-2000:], language="log")
    
    with col2:
        st.subheader("🔧 Backend API")
        if backend_running:
            st.success(f"**Status:** Running (PID: {backend_pid})")
            # Try to get port from logs or config
            st.info("**Health:** ✅ Running")
        else:
            st.error("**Status:** Stopped")
        
        if st.button("View Backend Logs", key="view_backend"):
            log_file = LOGS_DIR / "backend.log"
            if log_file.exists():
                st.code(log_file.read_text()[-2000:], language="log")
    
    with col3:
        st.subheader("🎨 Frontend UI")
        if frontend_running:
            st.success(f"**Status:** Running (PID: {frontend_pid})")
        else:
            st.info("**Status:** Not started")
            st.caption("Frontend is optional")
    
    # System metrics
    st.markdown("---")
    st.subheader("📈 System Metrics")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        env = load_env_file()
        max_tokens = env.get("COVERITY_ASSIST_MAX_TOKENS", "8192")
        st.metric("Max Tokens", max_tokens)
    
    with col2:
        proxy_cap = env.get("COVERITY_ASSIST_PROXY_MAX_TOKENS", "16384")
        st.metric("Proxy Cap", proxy_cap)
    
    with col3:
        agent_mode = env.get("COVERITY_ASSIST_AGENT_TOOL_MODE", "0")
        st.metric("Agent Mode", "Enabled" if agent_mode == "1" else "Disabled")
    
    with col4:
        tool_steps = env.get("COVERITY_ASSIST_TOOL_MAX_STEPS", "100")
        st.metric("Tool Steps", tool_steps)

with tab2:
    st.header("⚙️ Configuration Settings")
    
    env = load_env_file()
    
    st.subheader("Core Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        max_tokens = st.number_input(
            "Default Max Tokens",
            min_value=1024,
            max_value=32768,
            value=int(env.get("COVERITY_ASSIST_MAX_TOKENS", "8192")),
            step=1024,
            help="Default max tokens for responses"
        )
        env["COVERITY_ASSIST_MAX_TOKENS"] = str(max_tokens)
        
        proxy_cap = st.number_input(
            "Proxy Max Tokens Cap",
            min_value=2048,
            max_value=32768,
            value=int(env.get("COVERITY_ASSIST_PROXY_MAX_TOKENS", "16384")),
            step=1024,
            help="Maximum tokens allowed by proxy"
        )
        env["COVERITY_ASSIST_PROXY_MAX_TOKENS"] = str(proxy_cap)
    
    with col2:
        agent_mode = st.checkbox(
            "Enable Agent Mode",
            value=env.get("COVERITY_ASSIST_AGENT_TOOL_MODE", "1") == "1",
            help="Enable agent tool mode"
        )
        env["COVERITY_ASSIST_AGENT_TOOL_MODE"] = "1" if agent_mode else "0"
        
        tool_steps = st.number_input(
            "Max Tool Steps",
            min_value=10,
            max_value=200,
            value=int(env.get("COVERITY_ASSIST_TOOL_MAX_STEPS", "100")),
            step=10,
            help="Maximum tool execution steps"
        )
        env["COVERITY_ASSIST_TOOL_MAX_STEPS"] = str(tool_steps)
    
    st.markdown("---")
    st.subheader("Advanced Settings")
    
    debug_mode = st.checkbox(
        "Debug Mode",
        value=env.get("DEBUG", "0") == "1",
        help="Enable verbose logging"
    )
    env["DEBUG"] = "1" if debug_mode else "0"
    
    coverity_url = st.text_input(
        "Coverity Assist URL",
        value=env.get("COVERITY_ASSIST_URL", "http://127.0.0.1:5001/chat"),
        help="Proxy URL for Coverity Assist"
    )
    env["COVERITY_ASSIST_URL"] = coverity_url
    
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("💾 Save Configuration", use_container_width=True):
            save_env_file(env)
            st.success("✅ Configuration saved! Restart services to apply.")
    
    with col2:
        if st.button("🔄 Reset to Defaults", use_container_width=True):
            default_env = {
                "COVERITY_ASSIST_MAX_TOKENS": "8192",
                "COVERITY_ASSIST_PROXY_MAX_TOKENS": "16384",
                "COVERITY_ASSIST_AGENT_TOOL_MODE": "1",
                "COVERITY_ASSIST_TOOL_MAX_STEPS": "100",
                "DEBUG": "1",
                "COVERITY_ASSIST_URL": "http://127.0.0.1:5001/chat"
            }
            save_env_file(default_env)
            st.success("✅ Reset to defaults! Refresh page.")

with tab3:
    st.header("📋 Service Logs")
    
    log_selection = st.selectbox(
        "Select Log File",
        ["proxy.log", "backend.log", "frontend.log"]
    )
    
    log_file = LOGS_DIR / log_selection
    
    col1, col2, col3 = st.columns([1, 1, 2])
    with col1:
        tail_lines = st.number_input("Show last N lines", min_value=10, max_value=1000, value=100, step=10)
    with col2:
        auto_refresh = st.checkbox("Auto-refresh (5s)")
    
    if log_file.exists():
        log_content = log_file.read_text()
        lines = log_content.split('\n')
        display_lines = lines[-tail_lines:] if len(lines) > tail_lines else lines
        st.code('\n'.join(display_lines), language="log", line_numbers=True)
        
        if auto_refresh:
            time.sleep(5)
            st.rerun()
    else:
        st.warning(f"Log file not found: {log_file}")
    
    st.markdown("---")
    
    if st.button("🗑️ Clear Logs"):
        for log in LOGS_DIR.glob("*.log"):
            log.write_text("")
        st.success("✅ Logs cleared!")

with tab4:
    st.header("ℹ️ About Dish-Chat Agent")
    
    st.markdown("""
    ### Enhanced Agent v2.0.0
    
    **Key Features:**
    - 🚀 8-16x increased max tokens (8192/16384 vs 1024/2048)
    - 🤖 Explicit agent mode configuration
    - 🔧 Automatic port conflict resolution
    - 📊 Enhanced logging and monitoring
    - 🎛️ GUI management interface
    
    **Components:**
    - **Proxy Gateway:** Coverity Assist gateway with enhanced token handling
    - **Backend API:** FastAPI application with agent tools
    - **Frontend UI:** (Optional) Web interface
    - **GUI Manager:** This Streamlit application
    
    **Documentation:**
    - Quick Start: `docs/START_HERE.md`
    - Technical Details: `docs/ENHANCEMENT_SUMMARY.md`
    - Full Docs: `docs/README.md`
    - Quick Reference: `docs/QUICKREF.txt`
    
    **Support:**
    - Logs: Check the Logs tab
    - Config: Use the Configuration tab
    - Status: Monitor the Dashboard tab
    
    ---
    
    **Version:** v2.0.0-enhanced  
    **Build Date:** 2026-03-27  
    **Base:** AgentJake with enhancements  
    """)
    
    st.markdown("---")
    st.subheader("🔧 Quick Actions")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📖 View README", use_container_width=True):
            readme = BASE_DIR / "docs" / "START_HERE.md"
            if readme.exists():
                st.markdown(readme.read_text())
    
    with col2:
        if st.button("🧪 Run Tests", use_container_width=True):
            test_script = BASE_DIR / "scripts" / "test-agent.sh"
            if test_script.exists():
                result = subprocess.run(
                    ["bash", str(test_script)],
                    capture_output=True,
                    text=True
                )
                st.code(result.stdout, language="bash")
    
    with col3:
        if st.button("📦 Check Version", use_container_width=True):
            version_file = BASE_DIR / "VERSION"
            if version_file.exists():
                st.code(version_file.read_text())

# Footer
st.sidebar.markdown("---")
st.sidebar.caption(f"Dish-Chat Agent Manager v2.0.0")
st.sidebar.caption(f"Updated: {time.strftime('%Y-%m-%d %H:%M:%S')}")
