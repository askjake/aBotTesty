#!/bin/bash
# Comprehensive test script for enhanced agent
# Updated: 2026-03-27

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
PROXY_URL="http://127.0.0.1:5000"
BACKEND_URL="http://127.0.0.1:8000"
AGENT_ROOT="/tmp/dish_chat_agent/chatbot_analysis/AgentJake"
LOG_DIR="$AGENT_ROOT/logs"

echo "================================================================================"
echo -e "${BLUE}Dish-Chat Enhanced Agent Test Suite${NC}"
echo "================================================================================"
echo ""

# Track results
TESTS_PASSED=0
TESTS_FAILED=0

# Test function
run_test() {
    local test_name="$1"
    local test_command="$2"
    
    echo -n "Testing: $test_name ... "
    if eval "$test_command" > /dev/null 2>&1; then
        echo -e "${GREEN}✓ PASS${NC}"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo -e "${RED}✗ FAIL${NC}"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

# Test 1: Proxy health
run_test "Proxy health endpoint" "curl -s -f $PROXY_URL/health"

# Test 2: Backend health
run_test "Backend health endpoint" "curl -s -f $BACKEND_URL/"

# Test 3: Proxy accepts POST
run_test "Proxy accepts POST requests" "curl -s -f -X POST $PROXY_URL/chat -H 'Content-Type: application/json' -d '{"messages":[{"role":"user","content":"test"}],"max_tokens":100}'"

# Test 4: Check proxy logs for max_tokens
run_test "Proxy logs show increased max_tokens" "grep -q '8192\|16384' $LOG_DIR/proxy.log"

# Test 5: Check backend logs for agent mode
run_test "Backend logs show agent mode enabled" "grep -qi 'agent' $LOG_DIR/backend.log"

# Test 6: Check for tool loading
run_test "Backend loaded tools" "grep -qi 'tool' $LOG_DIR/backend.log"

# Test 7: Proxy process running
run_test "Proxy process is running" "pgrep -f coverity_assist_gateway_chat_proxy"

# Test 8: Backend process running
run_test "Backend process is running" "pgrep -f 'uvicorn app.main:app'"

# Test 9: Check .env configuration
run_test ".env has AGENT_TOOL_MODE=1" "grep -q 'COVERITY_ASSIST_AGENT_TOOL_MODE=1' $AGENT_ROOT/backend/.env"

# Test 10: Check .env max_tokens config
run_test ".env has increased max_tokens" "grep -q 'COVERITY_ASSIST_PROXY_MAX_TOKENS=16384' $AGENT_ROOT/backend/.env"

# Summary
echo ""
echo "================================================================================"
echo -e "${BLUE}Test Results${NC}"
echo "================================================================================"
echo -e "Passed: ${GREEN}$TESTS_PASSED${NC}"
echo -e "Failed: ${RED}$TESTS_FAILED${NC}"
echo ""

if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}✓ All tests passed!${NC}"
    echo "The enhanced agent is working correctly."
    exit 0
else
    echo -e "${RED}✗ Some tests failed${NC}"
    echo "Check the logs for more details:"
    echo "  Proxy:   $LOG_DIR/proxy.log"
    echo "  Backend: $LOG_DIR/backend.log"
    exit 1
fi
