#!/bin/bash
# Enhanced Dish-Chat Agent Startup Script
# Updated: 2026-03-27 v3 (FINAL)
# Purpose: Start agent with automatic port selection and proper configuration

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Directories
AGENT_ROOT="/tmp/dish_chat_agent/chatbot_analysis/AgentJake"
ENHANCED_DIR="/tmp/dish_chat_agent/chatbot_analysis/enhanced"
BACKEND_DIR="$AGENT_ROOT/backend"
LOG_DIR="$AGENT_ROOT/logs"

# Python executables - use correct ones for each service
PROXY_PYTHON="/home/montjac/JAMboree/JAMboree/vJAM/bin/python"  # Has Flask
BACKEND_PYTHON="/home/montjac/dish-chat/.venv/bin/python"        # Has uvicorn

# Create log directory
mkdir -p "$LOG_DIR"

echo "================================================================================"
echo -e "${BLUE}Dish-Chat Enhanced Agent Startup (v3)${NC}"
echo "================================================================================"
echo ""

# Function to find a free port
find_free_port() {
    local start_port=$1
    local end_port=$2
    
    for port in $(seq $start_port $end_port); do
        if ! lsof -Pi :$port -sTCP:LISTEN -t >/dev/null 2>&1; then
            echo $port
            return 0
        fi
    done
    
    echo "0"
    return 1
}

# Function to wait for service to be ready
wait_for_service() {
    local url=$1
    local max_attempts=30
    local attempt=0
    
    echo -n "Waiting for service to be ready"
    while [ $attempt -lt $max_attempts ]; do
        if curl -s "$url" > /dev/null 2>&1; then
            echo -e " ${GREEN}✓${NC}"
            return 0
        fi
        echo -n "."
        sleep 1
        attempt=$((attempt + 1))
    done
    
    echo -e " ${RED}✗${NC}"
    return 1
}

# Step 1: Find free ports
echo -e "${BLUE}[1/6] Finding free ports...${NC}"
PROXY_PORT=$(find_free_port 5000 5100)
BACKEND_PORT=$(find_free_port 8000 8100)

if [ "$PROXY_PORT" = "0" ] || [ "$BACKEND_PORT" = "0" ]; then
    echo -e "${RED}✗ Could not find free ports${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Proxy port: $PROXY_PORT${NC}"
echo -e "${GREEN}✓ Backend port: $BACKEND_PORT${NC}"
echo ""

# Step 2: Copy enhanced files
echo -e "${BLUE}[2/6] Deploying enhanced files...${NC}"

# Backup original files
BACKUP_DIR="$BACKEND_DIR/backups/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
if [ -f "$BACKEND_DIR/coverity_assist_gateway_chat_proxy.py" ]; then
    cp "$BACKEND_DIR/coverity_assist_gateway_chat_proxy.py" "$BACKUP_DIR/"
fi
if [ -f "$BACKEND_DIR/.env" ]; then
    cp "$BACKEND_DIR/.env" "$BACKUP_DIR/"
fi

# Deploy enhanced files
cp "$ENHANCED_DIR/coverity_assist_gateway_chat_proxy.py" "$BACKEND_DIR/"
cp "$ENHANCED_DIR/.env" "$BACKEND_DIR/"

echo -e "${GREEN}✓ Enhanced proxy deployed${NC}"
echo -e "${GREEN}✓ Enhanced .env deployed${NC}"
echo -e "${YELLOW}✓ Backup created: $BACKUP_DIR${NC}"
echo ""

# Step 3: Start Coverity Assist Proxy
echo -e "${BLUE}[3/6] Starting Coverity Assist Gateway Proxy...${NC}"

cd "$BACKEND_DIR"
# Check if already running
if pgrep -f "coverity_assist_gateway_chat_proxy.py --port" > /dev/null; then
    echo -e "${YELLOW}⚠ Proxy already running, stopping it first${NC}"
    pkill -f "coverity_assist_gateway_chat_proxy.py --port"
    sleep 2
fi

# Start proxy using JAMboree Python (has Flask)
nohup $PROXY_PYTHON coverity_assist_gateway_chat_proxy.py --port $PROXY_PORT > "$LOG_DIR/proxy.log" 2>&1 &
PROXY_PID=$!

echo -e "${GREEN}✓ Proxy started (PID: $PROXY_PID)${NC}"
echo -e "  Port: $PROXY_PORT"
echo -e "  Log: $LOG_DIR/proxy.log"
echo ""

# Wait for proxy to be ready
if ! wait_for_service "http://127.0.0.1:$PROXY_PORT/health"; then
    echo -e "${RED}✗ Proxy failed to start${NC}"
    echo -e "Check logs: tail -f $LOG_DIR/proxy.log"
    exit 1
fi

# Step 4: Update .env with actual proxy port
echo -e "${BLUE}[4/6] Updating configuration with actual ports...${NC}"
sed -i "s|COVERITY_ASSIST_URL=http://127.0.0.1:[0-9]*/chat|COVERITY_ASSIST_URL=http://127.0.0.1:$PROXY_PORT/chat|" "$BACKEND_DIR/.env"
echo -e "${GREEN}✓ Configuration updated to use proxy on port $PROXY_PORT${NC}"
echo ""

# Step 5: Start Backend
echo -e "${BLUE}[5/6] Starting Dish-Chat Backend...${NC}"

cd "$BACKEND_DIR"
# Check if already running on our port range
EXISTING_BACKEND=$(pgrep -f "uvicorn app.main:app --host 0.0.0.0 --port $BACKEND_PORT" || echo "")
if [ -n "$EXISTING_BACKEND" ]; then
    echo -e "${YELLOW}⚠ Backend already running on port $BACKEND_PORT, stopping it first${NC}"
    kill $EXISTING_BACKEND
    sleep 2
fi

# Use dish-chat venv (has uvicorn and all dependencies)
nohup $BACKEND_PYTHON -m uvicorn app.main:app --host 0.0.0.0 --port $BACKEND_PORT --reload > "$LOG_DIR/backend.log" 2>&1 &
BACKEND_PID=$!
echo -e "${GREEN}✓ Backend started (PID: $BACKEND_PID)${NC}"

echo -e "  Port: $BACKEND_PORT"
echo -e "  Log: $LOG_DIR/backend.log"
echo ""

# Wait for backend to be ready
if ! wait_for_service "http://127.0.0.1:$BACKEND_PORT/"; then
    echo -e "${RED}✗ Backend failed to start${NC}"
    echo -e "Check logs: tail -f $LOG_DIR/backend.log"
    exit 1
fi

# Step 6: Display status
echo -e "${BLUE}[6/6] Service Status${NC}"
echo "================================================================================"
echo -e "${GREEN}✓ All services started successfully!${NC}"
echo ""
echo "Services:"
echo -e "  Proxy:   http://127.0.0.1:$PROXY_PORT   (PID: $PROXY_PID)"
echo -e "  Backend: http://127.0.0.1:$BACKEND_PORT (PID: $BACKEND_PID)"
echo ""
echo "Test URLs:"
echo -e "  ${YELLOW}curl http://127.0.0.1:$PROXY_PORT/health${NC}"
echo -e "  ${YELLOW}curl http://127.0.0.1:$BACKEND_PORT/${NC}"
echo ""
echo "Logs:"
echo -e "  Proxy:   tail -f $LOG_DIR/proxy.log"
echo -e "  Backend: tail -f $LOG_DIR/backend.log"
echo ""
echo "To stop services:"
echo -e "  ${YELLOW}kill $PROXY_PID $BACKEND_PID${NC}"
echo ""
echo "Configuration:"
echo -e "  ✓ Max tokens: 8192 (default), 16384 (cap)"
echo -e "  ✓ Agent mode: ENABLED"
echo -e "  ✓ Tool steps: 100"
echo -e "  ✓ Backup: $BACKUP_DIR"
echo "================================================================================"

# Save PIDs for easy stopping later
echo "$PROXY_PID" > "$AGENT_ROOT/proxy.pid"
echo "$BACKEND_PID" > "$AGENT_ROOT/backend.pid"
echo "Saved PIDs to $AGENT_ROOT/{proxy,backend}.pid"
