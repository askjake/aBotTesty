import logging
from typing import Annotated, Any
from typing_extensions import TypedDict
from functools import cache

from langchain_core.messages import BaseMessage, SystemMessage, AIMessage, ToolMessage
from langgraph.graph.message import add_messages
from langgraph.graph import END, StateGraph, START
from langgraph.prebuilt import ToolNode

from app.core.llm import get_model
from app.config import get_settings
from app.core.utils import get_datestr_now
from app.core.prompt_compression import get_prompt_compressor

from ..db_utils import get_checkpointer
from ..utils import aggressive_cachept, cleanup_cachept, set_model_config
from .utils import get_prompt
from .tools import get_tools_set

logger = logging.getLogger(__name__)

settings = get_settings()
system_prompt = SystemMessage(
    content=get_prompt("chat_system").format(today=get_datestr_now())
)


class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]
    model_config: dict[str, Any]


### Nodes
async def call_model(state: AgentState, config=None):
    """
    Call the model with tools enabled.
    The model can choose to use tools or respond directly.
    
    Now includes prompt compression to handle long conversations.
    """
    messages = state["messages"]
    
    # Remove leading orphaned ToolMessages (can happen after truncation)
    while messages and isinstance(messages[0], ToolMessage):
        messages = messages[1:]
    
    # Remove orphaned tool calls/results - two-pass approach
    # Pass 1: Find all tool call IDs that have results
    tool_results_present = set()
    for msg in messages:
        if isinstance(msg, ToolMessage) and hasattr(msg, 'tool_call_id'):
            tool_results_present.add(msg.tool_call_id)
    
    # Pass 2: Only keep messages that are complete
    cleaned_messages = []
    for msg in messages:
        # For AI messages with tool calls, only keep if ALL tool results are present
        if isinstance(msg, AIMessage) and hasattr(msg, 'tool_calls') and msg.tool_calls:
            all_results_present = all(
                tc.get('id') in tool_results_present 
                for tc in msg.tool_calls
            )
            if all_results_present:
                cleaned_messages.append(msg)
            # Otherwise skip this AI message with incomplete tool calls
        # For tool messages, only keep if they're in our results set
        elif isinstance(msg, ToolMessage):
            if hasattr(msg, 'tool_call_id') and msg.tool_call_id in tool_results_present:
                cleaned_messages.append(msg)
        else:
            # Keep all other message types (Human, System, etc.)
            cleaned_messages.append(msg)
    
    messages = cleaned_messages
    
    # PROMPT COMPRESSION: Check if messages are too long
    # Extract chat_id from config for archiving
    chat_id = config.get("configurable", {}).get("thread_id", "unknown") if config else "unknown"
    
    compressor = get_prompt_compressor()
    if compressor.needs_compression(messages):
        logger.warning(f"Prompt exceeds threshold for chat {chat_id}. Applying compression...")
        messages, archive_path = compressor.compress_messages(messages, chat_id)
        
        if archive_path:
            logger.info(f"Original prompt archived at: {archive_path}")
            # Optionally, we could add a notification to the user here
    
    # Legacy truncation as fallback (if still too long after compression)
    if len(messages) > 1000:
        logger.warning(f"Messages still exceed 1000 after compression. Applying hard truncation.")
        messages = messages[-1000:]
    
    cleanup_cachept(messages)
    messages = aggressive_cachept(messages, settings.MAX_CACHEPOINT_CNT)
    
    # Get the model and bind tools
    model = get_model()
    set_model_config(model, state["model_config"])
    
    # Get tools: search (public web + internal) + agent_mode (git, venv, python)
    tools = get_tools_set("search") + get_tools_set("agent_mode")
    model_with_tools = model.bind_tools(tools)
    
    # Debug: log message types and tool call status
    logger.info(f"Calling model with {len(messages)} messages (after compression/cleanup)")
    for i, msg in enumerate(messages):
        msg_type = type(msg).__name__
        has_tool_calls = hasattr(msg, 'tool_calls') and msg.tool_calls
        tool_call_id = getattr(msg, 'tool_call_id', None)
        logger.info(f"  [{i}] {msg_type} - tool_calls: {has_tool_calls}, tool_call_id: {tool_call_id}")
    
    # Call the model
    response = await model_with_tools.ainvoke([system_prompt, *messages], config=config)
    
    # Cleanup the cachepoints so they're not stored persistently
    cleanup_cachept(messages)
    
    return {"messages": [response]}


def should_continue(state: AgentState) -> str:
    """
    Determine if we should continue to tools or end.
    """
    messages = state["messages"]
    last_message = messages[-1]
    
    # If the model made tool calls, route to tools
    if isinstance(last_message, AIMessage) and last_message.tool_calls:
        return "tools"
    
    # Otherwise, we're done
    return END


### Graph
@cache
def get_graph():
    # Get tools for the tool node
    tools = get_tools_set("search") + get_tools_set("agent_mode")
    
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("agent", call_model)
    workflow.add_node("tools", ToolNode(tools))
    
    # Add edges
    workflow.add_edge(START, "agent")
    workflow.add_conditional_edges(
        "agent",
        should_continue,
        {
            "tools": "tools",
            END: END,
        },
    )
    workflow.add_edge("tools", "agent")
    
    return workflow.compile(checkpointer=get_checkpointer())
