import { FloatButtonGroupProps } from 'antd';

type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>;
type PartialBy<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export interface ChatSettingsProps
  extends PartialBy<FloatButtonGroupProps, 'children'> {}
