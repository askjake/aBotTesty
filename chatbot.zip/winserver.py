# winserver.py
# Windows-safe launcher for Dish-Chat backend.
#
# Why this exists:
# psycopg async pools (used by langgraph-checkpoint-postgres) cannot run under
# Windows' default ProactorEventLoop. We force Selector policy AND we also
# explicitly create and run a Selector loop for the server.
#
# Run:
#   .\.venv\Scripts\python.exe winserver.py
#
import os
import sys
import asyncio

if sys.platform.startswith("win"):
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())  # type: ignore[attr-defined]
    except Exception as e:
        print(f"[WIN_LOOP] Failed to set WindowsSelectorEventLoopPolicy: {e!r}")

from uvicorn import Config, Server  # noqa: E402

def main() -> int:
    host = os.environ.get("FASTAPI_HOST") or "0.0.0.0"
    port = int(os.environ.get("FASTAPI_PORT") or "8000")
    log_level = os.environ.get("LOG_LEVEL") or "info"

    # Explicitly create the loop from the current policy.
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    print(f"[WIN_LOOP] policy={asyncio.get_event_loop_policy().__class__.__name__}")
    print(f"[WIN_LOOP] loop={loop.__class__.__name__}")

    # Hard fail if we somehow still got Proactor.
    if "Proactor" in loop.__class__.__name__:
        print("[WIN_LOOP] ERROR: Still using ProactorEventLoop. Aborting.")
        return 2

    config = Config(
        "app.main:app",
        host=host,
        port=port,
        loop="asyncio",
        log_level=log_level,
        reload=False,
        access_log=True,
    )
    server = Server(config)

    try:
        loop.run_until_complete(server.serve())
    finally:
        try:
            loop.close()
        except Exception:
            pass
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
