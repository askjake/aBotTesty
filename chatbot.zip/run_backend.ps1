# run_backend.ps1 - Windows backend runner (Selector loop via winserver.py)
$ErrorActionPreference = "Stop"

$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONPATH = (Get-Location).Path

$py = Join-Path (Get-Location).Path ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) { $py = "python" }

& $py "winserver.py"
exit $LASTEXITCODE
