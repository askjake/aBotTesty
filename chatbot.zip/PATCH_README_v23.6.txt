# v23.6 loopfix3 (Windows)

This patch fixes psycopg async PoolTimeout on Windows by forcing a Selector event loop.

## Apply
From PowerShell, in the project root:
  Expand-Archive ..\dish-chat-windows-native-bundle-v23.6-loopfix3.zip -DestinationPath . -Force

## Verify (recommended)
  .\.venv\Scripts\python.exe verify_windows_event_loop.py
Expected:
  policy: WindowsSelectorEventLoopPolicy
  loop: SelectorEventLoop

## Start backend (recommended)
  .\run_backend.bat
(or)
  powershell -NoProfile -ExecutionPolicy Bypass -File .\run_backend.ps1

You should see:
  [WIN_LOOP] policy=WindowsSelectorEventLoopPolicy
  [WIN_LOOP] loop=SelectorEventLoop

If it prints ProactorEventLoop, the process is not using this launcher.
Make sure startup scripts call run_backend.bat / run_backend.ps1 instead of invoking uvicorn directly.
