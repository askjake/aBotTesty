# verify_windows_event_loop.py
# Quick sanity check: prints the loop policy and a created loop class.
import sys, asyncio
if sys.platform.startswith("win"):
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())  # type: ignore[attr-defined]
print("policy:", asyncio.get_event_loop_policy().__class__.__name__)
loop = asyncio.new_event_loop()
print("loop:", loop.__class__.__name__)
loop.close()
