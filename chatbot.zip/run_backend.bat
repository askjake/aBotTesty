@echo off
setlocal

REM Windows backend runner (forces Selector event loop via winserver.py)
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set PYTHONPATH=%CD%

if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" winserver.py
) else (
  python winserver.py
)

endlocal
