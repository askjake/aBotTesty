"""LLM Configuration Module"""
