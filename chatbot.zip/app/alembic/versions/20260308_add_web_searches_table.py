"""create web_searches table for analytics logging

Revision ID: 20260308_add_web_searches
Revises: aa1b2c3d4e5f
Create Date: 2026-03-08
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "20260308_add_web_searches"
down_revision: Union[str, None] = "aa1b2c3d4e5f"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    op.create_table(
        "web_searches",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("chat_id", sa.String(), nullable=False, index=True),
        sa.Column("query", sa.Text(), nullable=False),
        sa.Column("results_json", postgresql.JSONB, nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("idx_web_searches_chat_created", "web_searches", ["chat_id", "created_at"], unique=False)

def downgrade() -> None:
    op.drop_index("idx_web_searches_chat_created", table_name="web_searches")
    op.drop_table("web_searches")
