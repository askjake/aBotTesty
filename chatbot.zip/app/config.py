from typing import Literal, Optional, ClassVar
from functools import lru_cache, cached_property
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import computed_field


@lru_cache
def get_settings():
    return Settings()


class Settings(BaseSettings):
    NAME: str = "Dish-Chat"
    VERSION: str = "2.1.1"
    API_PREFIX: str = "/rest/api/v1"

    # Runtime settings
    DEBUG: bool = False
    LOCAL: bool = True

    # ==========================================================================
    # AUTHENTICATION SETTINGS - ATLASSIAN SSO INTEGRATION
    # ==========================================================================
    AUTH_DISABLED: bool = True
    DEFAULT_USER_EMAIL: str = "jacob.montgomery@dish.com"

    ECHO_SQL: bool = False
    FASTAPI_HOST: str = "0.0.0.0"
    FASTAPI_PORT: int = 8000
    CLEANUP_TIMEOUT: int = 600

    # Idle chat checker settings
    IDLE_CHAT_CHECKER_ENABLED: bool = True
    IDLE_CHAT_CHECK_INTERVAL_MINUTES: int = 60
    IDLE_CHAT_THRESHOLD_MINUTES: int = 30
    IDLE_CHAT_MIN_MESSAGES: int = 5
    SPOOLED_MAX_SIZE: int = 2 * 1024 * 1024
    MASTER_KEY: str = "SoWTrLlo3xu1ExZIvSNQMpldDmUHc5cxbmrxlPN2RvI="

    # DB
    POSTGRES_HOST: str = "127.0.0.1"
    POSTGRES_PORT: int = 5434
    POSTGRES_DB: str = "dishchat"
    POSTGRES_USER: str = "dev_user"
    POSTGRES_PWD: str = "dev123"

    @computed_field
    @cached_property
    def POSTGRES_URL(self) -> str:
        return (
            f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PWD}@"
            f"{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        )

    @computed_field
    @cached_property
    def POSTGRES_SQLALCHEMY_URL(self) -> str:
        return (
            f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PWD}@"
            f"{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        )

    # LLM Models - P for Power and E for Efficient
    PLLM_PROVIDER: Literal[
        "aws-bedrock", "openai", "anthropic", "ollama", "coverity-assist"
    ] = "aws-bedrock"
    PLLM_API_BASE: Optional[str] = None
    PLLM_MODEL: str = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
    PLLM_CTX_LEN: int = 200_000

    ELLM_PROVIDER: Optional[
        Literal["aws-bedrock", "openai", "anthropic", "ollama", "coverity-assist"]
    ] = "aws-bedrock"
    ELLM_API_BASE: Optional[str] = None
    ELLM_MODEL: Optional[str] = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
    ELLM_CTX_LEN: Optional[int] = 200_000
    LLM_TOKENIZER: Optional[str] = None
    DEFAULT_TEMP: float = 0.6
    DEFAULT_REASONING: bool = False
    REASONING_BUDGET: int = 6000

    # Embeddings
    EMBED_PROVIDER: Literal["aws-bedrock", "openai", "ollama"] = "aws-bedrock"
    EMBED_API_BASE: Optional[str] = None
    EMBED_MODEL: str = "cohere.embed-multilingual-v3"
    EMBED_TOKENIZER: str = "Cohere/Cohere-embed-multilingual-v3.0"
    EMBED_CHUNK_SIZE: int = 300
    EMBED_OVERLAP: int = 5
    EMBED_BATCH_SIZE: int = 96
    SUMMARY_LEN: int = 300

    # AWS Settings
    AWS_REGION: Optional[str] = "us-west-2"
    AWS_ACCESS_KEY_ID: Optional[str] = None
    AWS_SECRET_ACCESS_KEY: Optional[str] = None
    AWS_ENDPOINT_URL: Optional[str] = None
    AWS_FILESTORE_BUCKET: str = "dish-chat-filestore"

    # Coverity Assist / gateway settings
    ENABLE_COVERITY_ASSIST: bool = False
    COVERITY_ASSIST_URL: str = "http://coverity-assist.dishtv.technology/chat"
    COVERITY_ASSIST_API_KEY: Optional[str] = None
    COVERITY_ASSIST_TOKEN: Optional[str] = None
    COVERITY_ASSIST_INFERENCE_PROFILE_ARN: Optional[str] = None
    COVERITY_ASSIST_TOP_LEVEL_SYSTEM: bool = False
    COVERITY_ASSIST_VERIFY_SSL: bool = False
    COVERITY_ASSIST_MAX_TOKENS: int = 200_000
    COVERITY_ASSIST_AGENT_TOOL_MODE: bool = True
    COVERITY_ASSIST_TOOL_MAX_STEPS: int = 100

    # AWS Bedrock Configuration
    BEDROCK_READ_TIMEOUT: int = 300
    BEDROCK_CONNECT_TIMEOUT: int = 30
    BEDROCK_MAX_RETRIES: int = 3
    BEDROCK_APPLICATION_INFERENCE_PROFILE_ARN: Optional[str] = None

    # Chat Settings
    MAX_CHAT_COUNT: int = 9999
    MAX_GROUPS_WITH_CHATS_COUNT: int = 20
    MAX_TITLE_LEN: int = 40
    MAX_TITLE_RETRY: int = 5

    # Message Settings
    MAX_VERSION_COUNT: int = 20
    MAX_IN_CTX_DOC_LEN: int = 200_000
    MAX_OUTPUT_COUNT: int = 64_000

    JOURNAL_MAX_MESSAGES: int = 4096

    # Attachment Settings
    SUPPORTED_DOC_TYPES: list[str] = [
        "application/pdf",
        "text/plain",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ]
    SUPPORTED_IMAGE_TYPES: list[str] = [
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
    ]
    MAX_IMAGE_RES: int = 1092 * 1092

    # Vault Settings
    VAULT_SESSION_DURATION_SEC: int = 3 * 3600
    ARGON2_TIME: int = 3
    ARGON2_MEM: int = 2**16
    ARGON2_PRL: int = 1

    # Context Manager
    MAX_CONTEXT: int = 12000
    MAX_CONV_CACHE: float = 0.6
    SUMMARIZE_WORD_LIMIT: int = 1500
    CACHE_EVICT_PROP: float = 0.5

    # Agent Settings
    MAX_CACHEPOINT_CNT: int = 4
    LANGGRAPH_RECURSION_LIMIT: int = 200
    AGENT_MODE_MODEL: Optional[str] = None
    AGENT_MODE_MAX_ITERS: int = 200
    AGENT_MODE_PERSONA: Literal["dish", "home"] = "dish"
    SUMMARY_MODEL_ARN: Optional[str] = None
    REVIEW_MODEL_ARN: Optional[str] = None

    # ==========================================================================
    # MCP SERVER CONFIGURATIONS
    # ==========================================================================
    BETAREPORT_MCP_CONFIG: dict = {
        "beta_report": {
            "transport": "streamable_http",
            "url": "https://7quifnvo576d2m5rhbnguwgvfq0qbivs.lambda-url.us-west-2.on.aws/mcp",
            "headers": {"Authorization": "Bearer yxuRJ1BuBuLRyha57xfmQXUcoWOJ7Tlw"},
        }
    }

    LOG_ASSIST_MCP_CONFIG: dict = {
        "log_assist": {
            "transport": "streamable_http",
            "url": "http://127.0.0.1:5000/mcp",
        }
    }

    INTERNAL_TOOLS_MCP_CONFIG: dict = {
        "internal_tools": {
            "transport": "streamable_http",
            "url": "https://internal-tools.yourdomain/mcp",
        }
    }

    # External service endpoints
    COVERITY_GATEWAY_URL: str = "http://127.0.0.1:5000"
    SENTRY_AUTH_TOKEN: Optional[str] = None
    SENTRY_ORG: str = "dishtv.technology"
    SENTRY_URL: str = "https://ds-testing-sentry.dishtv.technology"
    SENTRY_PROJECT: Optional[str] = None

    INTERNAL_SEARCH_URL: str = "https://internal-search.yourdomain/api/search"
    INTERNAL_SEARCH_MODE: str = "multi"
    INTERNAL_SEARCH_TIMEOUT: float = 10.0
    INTERNAL_SEARCH_SOURCES: str = "confluence,gitlab,jira"

    CART_HOST: Optional[str] = "cart.dtc.dish.corp"
    CCTOOLS_HOST: Optional[str] = "cctools.dtc.dish.corp"
    PORTAL_HOST: Optional[str] = "inlpecca01.dtc.dish.corp"
    INTERNAL_TOOLS_TIMEOUT: float = 30.0

    CONFLUENCE_BASE_URL: str = "https://dishtech-dishtv.atlassian.net/wiki"
    CONFLUENCE_USER_EMAIL: Optional[str] = None
    CONFLUENCE_API_TOKEN: Optional[str] = None

    GITLAB_BASE_URL: str = "https://gitlab.com"
    GITLAB_TOKEN: Optional[str] = None
    GITLAB_SEARCH_SCOPES: str = "projects,blobs"

    JIRA_BASE_URL: str = "https://dishtech-dishtv.atlassian.net"
    JIRA_USER_EMAIL: Optional[str] = None
    JIRA_API_TOKEN: Optional[str] = None

    ALLOWED_NAMESPACES: ClassVar[list[str]] = [
        "generic",
        "log_assist",
        "beta_report",
        "agent_mode",
    ]

    model_config = SettingsConfigDict(
        env_file=(".env", ".env.local"),
        extra="ignore",
    )

    # MCP TOOL ENABLE/DISABLE FLAGS
    ENABLE_BETAREPORT_MCP: bool = True
    ENABLE_VIEWERSHIP_MCP: bool = False
    ENABLE_LOG_ASSIST_MCP: bool = True
    ENABLE_INTERNAL_TOOLS_MCP: bool = False

    # CORS / FRONTEND ORIGINS
    CORS_ALLOWED_ORIGINS: list[str] = [
        "http://localhost:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3001",
        "http://10.79.83.40:3000",
        "http://10.79.83.40:3001",
        "http://10.79.85.35:3000",
        "http://10.79.85.35:3001",
        "http://dsgpu3090-lambda-vector:3000",
        "http://dsgpu3090-lambda-vector:3001",
        "https://chat-agent.dishtv.technology",
        "http://chat-agent.dishtv.technology",
    ]
