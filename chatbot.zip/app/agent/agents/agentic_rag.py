import logging
from typing import Annotated, Any
from typing_extensions import TypedDict
from functools import cache

from langchain_core.messages import BaseMessage, SystemMessage, AIMessage, ToolMessage
from langgraph.graph.message import add_messages
from langgraph.graph import END, StateGraph, START
from langgraph.prebuilt import ToolNode

from app.core.llm import get_model
from app.config import get_settings
from app.core.utils import get_datestr_now
from app.core.prompt_compression import get_prompt_compressor

from ..db_utils import get_checkpointer
from ..utils import aggressive_cachept, cleanup_cachept, set_model_config
from .utils import get_prompt
from ..methodology_utils import inject_methodology_into_prompt
from .tools import get_tools_set
from .coverity_tool_loop import run_coverity_tool_loop

logger = logging.getLogger(__name__)
settings = get_settings()

system_prompt = SystemMessage(
    content=get_prompt("chat_system").format(
        today=get_datestr_now(),
        token_budget=getattr(settings, "MAX_OUTPUT_COUNT", 2048),
    )
)


class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]
    model_config: dict[str, Any]


def _clean_messages(messages: list[BaseMessage]) -> list[BaseMessage]:
    while messages and isinstance(messages[0], ToolMessage):
        messages = messages[1:]

    tool_results_present = set()
    for msg in messages:
        if isinstance(msg, ToolMessage) and hasattr(msg, "tool_call_id"):
            tool_results_present.add(msg.tool_call_id)

    cleaned_messages = []
    for msg in messages:
        if isinstance(msg, AIMessage) and hasattr(msg, "tool_calls") and msg.tool_calls:
            all_results_present = all(
                tc.get("id") in tool_results_present for tc in msg.tool_calls
            )
            if all_results_present:
                cleaned_messages.append(msg)
        elif isinstance(msg, ToolMessage):
            if hasattr(msg, "tool_call_id") and msg.tool_call_id in tool_results_present:
                cleaned_messages.append(msg)
        else:
            cleaned_messages.append(msg)

    return cleaned_messages


def _last_user_message(messages: list[BaseMessage]) -> str:
    for msg in reversed(messages):
        if getattr(msg, "type", "") == "human":
            content = getattr(msg, "content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                parts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        parts.append(item.get("text", ""))
                    elif isinstance(item, str):
                        parts.append(item)
                return "\n".join(p for p in parts if p)
            return str(content)
    return ""


async def call_model(state: AgentState, config=None):
    """
    Call the model with tools enabled.

    Behavior goals:
    - preserve complete tool-call / tool-result pairs
    - apply prompt compression before hard truncation
    - inject methodology when user asks for it
    - use native tool-calling for non-coverity providers
    - use the Coverity planner/tool loop for coverity-assist provider
    """
    messages = _clean_messages(state["messages"])

    chat_id = config.get("configurable", {}).get("thread_id", "unknown") if config else "unknown"

    compressor = get_prompt_compressor()
    if compressor.needs_compression(messages):
        logger.warning("Prompt exceeds threshold for chat %s. Applying compression...", chat_id)
        messages, archive_path = compressor.compress_messages(messages, chat_id)
        if archive_path:
            logger.info("Original prompt archived at: %s", archive_path)

    if len(messages) > 1000:
        logger.warning("Messages still exceed 1000 after compression. Applying hard truncation.")
        messages = messages[-1000:]

    cleanup_cachept(messages)
    messages = aggressive_cachept(messages, settings.MAX_CACHEPOINT_CNT)

    model = get_model()
    set_model_config(model, state["model_config"])

    # Tools: search + agent_mode. Keep this aligned with original Dish-Chat behavior.
    tools = get_tools_set("search") + get_tools_set("agent_mode")
    model_with_tools = model.bind_tools(tools)

    logger.info("Calling model with %d messages (after compression/cleanup)", len(messages))
    for i, msg in enumerate(messages):
        msg_type = type(msg).__name__
        has_tool_calls = hasattr(msg, "tool_calls") and msg.tool_calls
        tool_call_id = getattr(msg, "tool_call_id", None)
        logger.info("  [%d] %s - tool_calls: %s, tool_call_id: %s", i, msg_type, bool(has_tool_calls), tool_call_id)

    user_message = _last_user_message(messages)
    dynamic_system_prompt = SystemMessage(
        content=inject_methodology_into_prompt(system_prompt.content, user_message)
    )

    if getattr(settings, "PLLM_PROVIDER", "") == "coverity-assist" or getattr(model, "_llm_type", "") == "coverity-assist":
        response = await run_coverity_tool_loop(
            model=model,
            tools=tools,
            messages=[dynamic_system_prompt, *messages],
            config=config,
        )
    else:
        response = await model_with_tools.ainvoke([dynamic_system_prompt, *messages], config=config)

    cleanup_cachept(messages)
    return {"messages": [response]}


def should_continue(state: AgentState) -> str:
    messages = state["messages"]
    last_message = messages[-1]

    if isinstance(last_message, AIMessage) and getattr(last_message, "tool_calls", None):
        return "tools"

    return END


@cache
def get_graph():
    tools = get_tools_set("search") + get_tools_set("agent_mode")

    workflow = StateGraph(AgentState)
    workflow.add_node("agent", call_model)
    workflow.add_node("tools", ToolNode(tools))

    workflow.add_edge(START, "agent")
    workflow.add_conditional_edges(
        "agent",
        should_continue,
        {
            "tools": "tools",
            END: END,
        },
    )
    workflow.add_edge("tools", "agent")

    return workflow.compile(checkpointer=get_checkpointer())
