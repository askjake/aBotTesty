from typing import BinaryIO
import os
import asyncio
from functools import cache
from pathlib import Path

from pdfminer.high_level import extract_text as extract_pdf_text
import docx2txt
from langchain_core.documents.base import Document
from langchain_core.embeddings import Embeddings
from langchain_aws import BedrockEmbeddings

try:
    from langchain_community.embeddings import OllamaEmbeddings  # type: ignore
except Exception:
    try:
        from langchain_community.embeddings.ollama import OllamaEmbeddings  # type: ignore
    except Exception:
        OllamaEmbeddings = None  # type: ignore

try:
    from langchain_openai import OpenAIEmbeddings  # type: ignore
except Exception:
    OpenAIEmbeddings = None  # type: ignore

from transformers import AutoTokenizer

from app.config import get_settings


settings = get_settings()

async def extract_text_from_pdf(file: BinaryIO) -> Document:
    content = await asyncio.to_thread(extract_pdf_text, file)
    return Document(page_content=content)
 

async def extract_text_from_doc(file: BinaryIO):
    content = await asyncio.to_thread(docx2txt.process, file)
    return Document(page_content=content)

async def extract_text_from_txt(file: BinaryIO):
    def read_txt(file: BinaryIO):
        return file.read().decode()
    content = await asyncio.to_thread(read_txt, file)
    return Document(page_content=content)

@cache
def get_embedder() -> Embeddings:
    """Creates and returns a cached Embeddings instance.

    Supported providers in this bundle:
      - aws-bedrock (BedrockEmbeddings)
      - ollama (OllamaEmbeddings; local)
      - openai (OpenAIEmbeddings; also works with OpenAI-compatible servers when EMBED_API_BASE is set)
    """

    if settings.EMBED_PROVIDER == "aws-bedrock":
        return BedrockEmbeddings(model_id=settings.EMBED_MODEL, region_name=settings.AWS_REGION)

    if settings.EMBED_PROVIDER == "ollama":
        if OllamaEmbeddings is None:
            raise RuntimeError("langchain-community is not installed; cannot use ollama embeddings")
        base_url = settings.EMBED_API_BASE or os.getenv("OLLAMA_BASE_URL") or "http://127.0.0.1:11434"
        return OllamaEmbeddings(model=settings.EMBED_MODEL, base_url=base_url)

    if settings.EMBED_PROVIDER == "openai":
        if OpenAIEmbeddings is None:
            raise RuntimeError("langchain-openai is not installed; cannot use openai embeddings")
        base_url = settings.EMBED_API_BASE or os.getenv("OPENAI_BASE_URL") or os.getenv("OPENAI_API_BASE")
        api_key = os.getenv("OPENAI_API_KEY", "ollama")
        kwargs: dict = {"model": settings.EMBED_MODEL, "api_key": api_key}
        if base_url:
            kwargs["base_url"] = base_url
            kwargs["openai_api_base"] = base_url
        return OpenAIEmbeddings(**kwargs)

    raise NotImplementedError(f"Embedding provider {settings.EMBED_PROVIDER} is not supported yet.")


@cache
def get_embedding_tokenizer():
    """
    Creates and returns a cached HF tokenizer for the embeddings

    Returns:
        Tokenizer: An instance of HF tokenizer
    """
    return AutoTokenizer.from_pretrained(settings.EMBED_TOKENIZER)


@cache
def get_prompt(name: str):
    current_dir = Path(__file__).parent
    prompt_path = current_dir / "prompts" / f"{name}_prompt.txt"
    with open(prompt_path) as f:
        prompt = f.read()
    return prompt
