"""Personality module for Dish-Chat."""
