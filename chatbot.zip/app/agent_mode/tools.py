import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional
import asyncio
import shlex
import json
import re


from langchain.tools import tool
from app.agent_mode.thought_interceptor import interceptor

# Root directory where agent-mode workspaces live
BASE_AGENT_WORKDIR = os.environ.get("AGENT_MODE_WORKDIR", "/tmp/dish_chat_agent")
Path(BASE_AGENT_WORKDIR).mkdir(parents=True, exist_ok=True)

# ============================================================================
# ENHANCED WHITELIST FOR HOME NETWORK MANAGEMENT
# ============================================================================

ALLOWED_BINARIES = {
    # Original enterprise tools (keep for compatibility)
    "aws", "kubectl", "helm", "bash", "git", "ls", "cat", "grep", "find",
    
    # Network connectivity & diagnostics
    "ping", "traceroute", "tracepath", "mtr", "dig", "nslookup", "host",
    "nc", "netcat", "curl", "wget", "telnet",
    
    # Network scanning & info
    "nmap", "ip", "ifconfig", "netstat", "ss", "arp", "route", "iptables",
    "ethtool", "iwconfig", "iw",
    
    # Remote access
    "ssh", "scp", "sftp", "rsync",
    
    # System monitoring
    "top", "htop", "ps", "free", "uptime", "df", "du", "iostat", "vmstat",
    "mpstat", "sar", "w", "who",
    
    # Hardware info
    "lshw", "lscpu", "lsusb", "lspci", "dmidecode", "sensors", "smartctl",
    "hdparm", "lsblk", "blkid",
    
    # Log viewing
    "tail", "head", "less", "more", "journalctl", "dmesg", "lastlog",
    
    # Text processing
    "awk", "sed", "sort", "uniq", "wc", "cut", "tr", "nl",
    
    # System info
    "uname", "hostname", "date", "cal", "timedatectl", "systemctl",
}


def _safe_workspace(chat_id: str) -> Path:
    '''Return a per-chat workspace directory, creating it if needed.'''
    ws = Path(BASE_AGENT_WORKDIR) / chat_id
    ws.mkdir(parents=True, exist_ok=True)
    return ws


def _venv_python(ws: Path) -> Path:
    '''Resolve the Python executable inside the workspace virtualenv.'''
    if os.name == "nt":
        return ws / ".venv" / "Scripts" / "python.exe"
    return ws / ".venv" / "bin" / "python"


def _validate_ip_address(ip: str) -> bool:
    '''Validate IP address format.'''
    pattern = r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$'
    if not re.match(pattern, ip):
        return False
    parts = ip.split('.')
    return all(0 <= int(part) <= 255 for part in parts)


def _detect_injection_patterns(command: str) -> Optional[str]:
    '''Detect command injection patterns for security.'''
    if not isinstance(command, str):
        return "Invalid command type"
    
    binary = shlex.split(command)[0] if command else ""
    
    # Allow pipes and redirects for bash and ssh (needed for remote commands)
    if binary in ["bash", "ssh", "scp"]:
        return None
    
    dangerous = [";", "&&", "||", "|", ">", ">>", "<", "`", "$(", "${", "\n"]
    for pattern in dangerous:
        if pattern in command:
            return f"Contains potentially dangerous pattern: {pattern}"
    
    return None


# ============================================================================
# ENHANCED SHELL COMMAND RUNNER
# ============================================================================

async def _run_shell_command(
    command: str,
    cwd: Optional[str] = None,
    timeout_seconds: int = 600,
) -> str:
    '''Run a shell command with security validation.'''
    parts = shlex.split(command)
    if not parts or parts[0] not in ALLOWED_BINARIES:
        return (
            f"Command rejected. '{parts[0] if parts else '<empty>'}' "
            f"is not in allowed list.\n"
            f"Allowed: {', '.join(sorted(ALLOWED_BINARIES)[:15])}... "
            f"({len(ALLOWED_BINARIES)} total)"
        )
    
    # Security validation
    injection_check = _detect_injection_patterns(command)
    if injection_check:
        interceptor.thought(f"SECURITY: Blocked command - {injection_check}", "error")
        return f"Command rejected for security: {injection_check}"
    
    interceptor.thought(f"Executing: {command[:150]}", "tool")
    
    proc = await asyncio.create_subprocess_shell(
        command,
        cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(), timeout=timeout_seconds
        )
    except asyncio.TimeoutError:
        proc.kill()
        return f"Command timed out after {timeout_seconds}s: {command}"

    out = stdout.decode("utf-8", errors="replace")
    err = stderr.decode("utf-8", errors="replace")

    # Truncate very long outputs
    if len(out) > 15000:
        out = out[:15000] + f"\n\n[Output truncated, {len(out)} total bytes]"
    if len(err) > 5000:
        err = err[:5000] + f"\n\n[Stderr truncated, {len(err)} total bytes]"

    return (
        f"Exit code: {proc.returncode}\n"
        f"STDOUT:\n{out or '<empty>'}\n\n"
        f"STDERR:\n{err or '<empty>'}"
    )


# ============================================================================
# ORIGINAL TOOLS (with proper docstrings)
# ============================================================================

@tool("agent_git_clone")
def agent_git_clone(chat_id: str, repo_url: str, branch: str = "main") -> str:
    '''Clone (or update) a Git repo into the agent workspace.

    - chat_id: Unique identifier for the current conversation.
    - repo_url: HTTPS or SSH URL for the repository.
    - branch: Branch to check out (default: main).

    The repo is placed under <BASE_AGENT_WORKDIR>/<chat_id>/repo.
    '''
    interceptor.tool_call("agent_git_clone", params={"repo_url": repo_url, "branch": branch})
    interceptor.thought(f"Cloning {repo_url}", "tool")
    
    ws = _safe_workspace(chat_id)
    repo_dir = ws / "repo"

    if repo_dir.exists():
        try:
            subprocess.run(
                ["git", "-C", str(repo_dir), "fetch", "--all"],
                check=True, capture_output=True, text=True, timeout=120,
            )
            subprocess.run(
                ["git", "-C", str(repo_dir), "checkout", branch],
                check=True, capture_output=True, text=True, timeout=60,
            )
            subprocess.run(
                ["git", "-C", str(repo_dir), "pull", "origin", branch],
                check=True, capture_output=True, text=True, timeout=120,
            )
            return f"Updated existing repo at {repo_dir} on branch {branch}."
        except Exception:
            shutil.rmtree(repo_dir, ignore_errors=True)

    repo_dir.parent.mkdir(parents=True, exist_ok=True)
    try:
        result = subprocess.run(
            ["git", "clone", "--branch", branch, repo_url, str(repo_dir)],
            check=True, capture_output=True, text=True, timeout=300,
        )
        return f"Cloned {repo_url} to {repo_dir} on branch {branch}.\nSTDOUT: {result.stdout}\nSTDERR: {result.stderr}"
    except subprocess.CalledProcessError as exc:
        return f"git clone failed: {exc}\nSTDOUT: {exc.stdout}\nSTDERR: {exc.stderr}"
    except Exception as exc:
        return f"git clone failed: {exc!r}"


@tool("agent_create_venv")
def agent_create_venv(chat_id: str, python_bin: Optional[str] = None) -> str:
    '''Create (or recreate) a virtualenv inside the workspace.

    - chat_id: Workspace id.
    - python_bin: Which Python to use (default: current interpreter).
    '''
    interceptor.tool_call("agent_create_venv", params={"python_bin": python_bin})
    interceptor.thought("Creating virtual environment", "tool")
    
    ws = _safe_workspace(chat_id)
    venv_dir = ws / ".venv"

    if python_bin is None:
        python_bin = os.environ.get("AGENT_MODE_PYTHON") or os.sys.executable

    if venv_dir.exists():
        return f"Virtualenv already exists at {venv_dir}."

    try:
        result = subprocess.run(
            [python_bin, "-m", "venv", str(venv_dir)],
            check=True, capture_output=True, text=True, timeout=300,
        )
        return f"Created virtualenv at {venv_dir}.\nSTDOUT: {result.stdout}\nSTDERR: {result.stderr}"
    except subprocess.CalledProcessError as exc:
        return f"venv creation failed: {exc}\nSTDOUT: {exc.stdout}\nSTDERR: {exc.stderr}"
    except Exception as exc:
        return f"venv creation failed: {exc!r}"


@tool("agent_run_python")
def agent_run_python(
    chat_id: str,
    code: str,
    filename: str = "agent_script.py",
    workdir_subdir: Optional[str] = None,
    use_venv: bool = True,
) -> str:
    '''Write Python code into the workspace and execute it.

    Parameters:
      - chat_id: Workspace id.
      - code: Python source code.
      - filename: Relative filename to write (default: agent_script.py).
      - workdir_subdir: Optional subdirectory under the workspace to use as CWD.
      - use_venv: If True, try to execute inside the workspace virtualenv.
    '''
    interceptor.tool_call("agent_run_python", params={"filename": filename, "code_length": len(code)})
    interceptor.thought(f"Executing {filename}", "tool")
    
    ws = _safe_workspace(chat_id)
    
    if workdir_subdir:
        ws = ws / workdir_subdir
        ws.mkdir(parents=True, exist_ok=True)

    target = ws / filename
    target.write_text(code, encoding="utf-8")

    if use_venv and _venv_python(_safe_workspace(chat_id)).exists():
        python = str(_venv_python(_safe_workspace(chat_id)))
    else:
        python = os.sys.executable

    try:
        result = subprocess.run(
            [python, str(target)],
            cwd=str(ws),
            capture_output=True,
            text=True,
            timeout=600,
        )
        return (
            f"Executed {target} (return code={result.returncode}).\n"
            f"STDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
        )
    except subprocess.TimeoutExpired as exc:
        return f"Execution timed out: {exc}"
    except Exception as exc:
        return f"Execution failed: {exc!r}"


@tool("agent_list_artifacts")
def agent_list_artifacts(chat_id: str) -> str:
    '''List generated files in the workspace and return download information.
    
    Returns a formatted list of files with download instructions.
    The AI should present these as markdown download links to the user.
    '''
    interceptor.tool_call("agent_list_artifacts", params={"chat_id": chat_id})
    
    ws = _safe_workspace(chat_id)
    if not ws.exists():
        return f"No workspace found for chat_id: {chat_id}"
    
    paths = []
    for root, dirs, files in os.walk(ws):
        # Skip venv directory
        if '.venv' in root:
            continue
        for f in files:
            full = Path(root) / f
            try:
                rel = full.relative_to(ws)
                size = full.stat().st_size
                paths.append(f"{rel} ({size} bytes)")
            except:
                pass
    
    if not paths:
        return "No artifacts found in workspace."
    
    return "Artifacts in workspace:\n" + "\n".join(sorted(paths)[:200])


@tool("agent_run_shell")
async def agent_run_shell(
    command: str,
    cwd: Optional[str] = None,
    timeout_seconds: int = 600,
) -> str:
    '''Run shell commands on the ops host.
    
    Use this for network/system admin commands to inspect or manage devices.
    Only allows whitelisted commands for security.
    
    Parameters:
      - command: Shell command to execute
      - cwd: Working directory (optional)
      - timeout_seconds: Timeout in seconds (default: 600)
    
    Example: agent_run_shell(command="ping -c 4 192.168.1.1")
    '''
    interceptor.tool_call("agent_run_shell", params={"command": command[:100], "cwd": cwd})
    interceptor.thought(f"Running: {command[:80]}", "tool")
    
    result = await _run_shell_command(command, cwd, timeout_seconds)
    
    if "Exit code: 0" in result:
        interceptor.tool_call("agent_run_shell", result="Success")
    else:
        interceptor.tool_call("agent_run_shell", result="Failed or non-zero exit")
    
    return result


# ============================================================================
# NEW TOOLS FOR HOME NETWORK MANAGEMENT
# ============================================================================

@tool("agent_network_scan")
async def agent_network_scan(
    subnet: str = "192.168.1.0/24",
    scan_type: str = "ping",
    chat_id: str = None,
) -> str:
    '''Scan the network to discover active devices using nmap.
    
    Parameters:
      - subnet: Network subnet to scan (e.g., "192.168.1.0/24")
      - scan_type: Type of scan - "ping" (fast), "quick" (common ports), "full" (all ports)
      - chat_id: Workspace ID for saving results
    
    Returns a list of discovered devices with IP addresses and hostnames.
    Results are automatically saved to the workspace.
    '''
    interceptor.tool_call("agent_network_scan", params={"subnet": subnet, "scan_type": scan_type})
    interceptor.thought(f"Scanning network {subnet}", "tool")
    
    # Validate subnet format
    if not re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/\d{1,2}$', subnet):
        return f"Invalid subnet format: {subnet}. Use format like 192.168.1.0/24"
    
    if scan_type == "ping":
        cmd = f"nmap -sn {subnet}"
    elif scan_type == "quick":
        cmd = f"nmap -F {subnet}"
    elif scan_type == "full":
        cmd = f"nmap -p- {subnet}"
    else:
        return f"Unknown scan_type: {scan_type}. Use: ping, quick, or full"
    
    result = await _run_shell_command(cmd, timeout_seconds=300)
    
    # Save to workspace if provided
    if chat_id and "Exit code: 0" in result:
        ws = _safe_workspace(chat_id)
        scan_file = ws / f"network_scan_{scan_type}.txt"
        scan_file.write_text(result, encoding="utf-8")
        result += f"\n\n[Results saved to: {scan_file}]"
    
    interceptor.tool_call("agent_network_scan", result="Scan complete")
    return result


@tool("agent_check_device")
async def agent_check_device(
    device: str,
    check_type: str = "basic",
) -> str:
    '''Check the status of a network device via SSH.
    
    Runs pre-configured health check commands on remote devices.
    
    Parameters:
      - device: Device address (user@ip or user@hostname)
      - check_type: Type of check to run:
        • "basic" - uptime, load, memory, disk
        • "disk" - detailed disk usage
        • "temp" - temperature sensors
        • "logs" - recent system logs
        • "network" - network interfaces and connections
        • "all" - comprehensive health check
    
    Examples:
      agent_check_device("pi@192.168.1.100", "basic")
      agent_check_device("admin@router.local", "logs")
    '''
    interceptor.tool_call("agent_check_device", params={"device": device, "check_type": check_type})
    
    checks = {
        "basic": "uptime && echo '---' && free -h && echo '---' && df -h",
        "disk": "df -h && echo '---' && du -sh /* 2>/dev/null | sort -h | tail -10",
        "temp": "sensors 2>/dev/null || vcgencmd measure_temp 2>/dev/null || echo 'No temp sensors found'",
        "logs": "tail -50 /var/log/syslog 2>/dev/null || journalctl -n 50 --no-pager",
        "network": "ip addr show && echo '---' && ss -tulpn",
        "all": "uptime && free -h && df -h && (sensors 2>/dev/null || echo 'No sensors') && tail -30 /var/log/syslog 2>/dev/null",
    }
    
    if check_type not in checks:
        return f"Unknown check_type: '{check_type}'. Available: {', '.join(checks.keys())}"
    
    cmd = f"ssh -o ConnectTimeout=10 -o StrictHostKeyChecking=accept-new {device} '{checks[check_type]}'"
    result = await _run_shell_command(cmd, timeout_seconds=60)
    
    return result


@tool("agent_save_device_info")
def agent_save_device_info(
    chat_id: str,
    device_name: str,
    ip_address: str,
    device_type: str = "unknown",
    notes: str = "",
    ssh_user: str = "",
) -> str:
    '''Save information about a network device to the persistent inventory.
    
    Creates or updates a JSON inventory file in the workspace that persists
    across chat sessions. Use this to build and maintain a database of your
    network devices.
    
    Parameters:
      - chat_id: Workspace ID
      - device_name: Friendly name for the device (e.g., "Living Room Pi")
      - ip_address: IP address (validated for proper format)
      - device_type: Type of device (router, switch, server, iot, raspberry-pi, etc.)
      - notes: Additional notes about the device
      - ssh_user: SSH username if device is SSH-accessible
    
    Returns confirmation with total device count.
    '''
    interceptor.tool_call("agent_save_device_info", params={
        "device_name": device_name,
        "ip_address": ip_address
    })
    
    # Validate IP
    if not _validate_ip_address(ip_address):
        return f"Invalid IP address format: {ip_address}"
    
    ws = _safe_workspace(chat_id)
    inventory_file = ws / "device_inventory.json"
    
    # Load existing inventory
    if inventory_file.exists():
        try:
            inventory = json.loads(inventory_file.read_text())
        except json.JSONDecodeError:
            inventory = {"devices": []}
    else:
        inventory = {"devices": []}
    
    # Create device entry
    device_entry = {
        "name": device_name,
        "ip": ip_address,
        "type": device_type,
        "notes": notes,
        "ssh_user": ssh_user,
        "last_updated": subprocess.check_output(["date", "-Iseconds"]).decode().strip(),
    }
    
    # Remove old entry if exists (update by IP)
    inventory["devices"] = [d for d in inventory["devices"] if d["ip"] != ip_address]
    inventory["devices"].append(device_entry)
    
    # Save
    inventory_file.write_text(json.dumps(inventory, indent=2))
    
    return f"✅ Saved '{device_name}' ({ip_address}) to inventory. Total devices: {len(inventory['devices'])}"


@tool("agent_list_devices")
def agent_list_devices(chat_id: str) -> str:
    '''List all devices in the persistent inventory.
    
    Retrieves and displays all devices that have been saved using
    agent_save_device_info. The inventory persists across chat sessions.
    
    Parameters:
      - chat_id: Workspace ID
    
    Returns a formatted list of all known devices with their details.
    '''
    ws = _safe_workspace(chat_id)
    inventory_file = ws / "device_inventory.json"
    
    if not inventory_file.exists():
        return "No device inventory found. Use agent_save_device_info() to add devices."
    
    try:
        inventory = json.loads(inventory_file.read_text())
        devices = inventory.get("devices", [])
    except json.JSONDecodeError:
        return "Error reading inventory file (corrupted JSON)."
    
    if not devices:
        return "Inventory file exists but contains no devices."
    
    result = f"📱 Network Device Inventory ({len(devices)} devices):\n\n"
    for d in sorted(devices, key=lambda x: x["ip"]):
        result += f"  • {d['name']} ({d['type']})\n"
        result += f"    IP: {d['ip']}"
        if d.get('ssh_user'):
            result += f" | SSH: {d['ssh_user']}@{d['ip']}"
        result += "\n"
        if d.get("notes"):
            result += f"    Notes: {d['notes']}\n"
        result += f"    Updated: {d.get('last_updated', 'unknown')}\n\n"
    
    return result
